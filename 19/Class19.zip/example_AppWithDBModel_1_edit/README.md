# About

Basic GAE project with Jinja templating engine

# Usage

1. Click on Download ZIP
2. Save on your disk and unzip
3. Change the application ID in app.yaml
4. Build something nice ;)
